package com.example.demo.Model.Customer;

public interface ICustomerObserver {
	 void update(String message, String email);
}
