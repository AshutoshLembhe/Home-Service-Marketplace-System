package com.example.demo.Model.ServiceProvider;

public interface IServiceProviderObserver {
    void update(String message, String email);
}
