package com.example.demo.Model.User;
public interface IUserFactory {
	User createUser(String UserType);
}
